import 'package:flutter/material.dart';

class AppConstants {
  // Predefined Categories with icons and colors
  static final Map<String, CategoryInfo> predefinedCategories = {
    'Food': CategoryInfo(
      icon: Icons.restaurant,
      color: const Color(0xFFFF6B6B),
    ),
    'Travel': CategoryInfo(icon: Icons.flight, color: const Color(0xFF4ECDC4)),
    'Bills': CategoryInfo(
      icon: Icons.receipt_long,
      color: const Color(0xFF45B7D1),
    ),
    'Shopping': CategoryInfo(
      icon: Icons.shopping_bag,
      color: const Color(0xFF96CEB4),
    ),
    'Entertainment': CategoryInfo(
      icon: Icons.movie,
      color: const Color(0xFFFFEAA7),
    ),
    'Health': CategoryInfo(
      icon: Icons.favorite,
      color: const Color(0xFFDDA0DD),
    ),
    'Education': CategoryInfo(
      icon: Icons.school,
      color: const Color(0xFF87CEEB),
    ),
    'Salary': CategoryInfo(
      icon: Icons.account_balance_wallet,
      color: const Color(0xFF00B894),
    ),
    'Freelance': CategoryInfo(
      icon: Icons.computer,
      color: const Color(0xFF0984E3),
    ),
    'Investment': CategoryInfo(
      icon: Icons.trending_up,
      color: const Color(0xFF6C5CE7),
    ),
    'Gift': CategoryInfo(
      icon: Icons.card_giftcard,
      color: const Color(0xFFFD79A8),
    ),
    'Other': CategoryInfo(
      icon: Icons.more_horiz,
      color: const Color(0xFF636E72),
    ),
  };

  static List<String> get expenseCategories => [
    'Food',
    'Travel',
    'Bills',
    'Shopping',
    'Entertainment',
    'Health',
    'Education',
    'Other',
  ];

  static List<String> get incomeCategories => [
    'Salary',
    'Freelance',
    'Investment',
    'Gift',
    'Other',
  ];

  static IconData getIconForCategory(String category) {
    return predefinedCategories[category]?.icon ?? Icons.category;
  }

  static Color getColorForCategory(String category) {
    return predefinedCategories[category]?.color ?? Colors.grey;
  }
}

class CategoryInfo {
  final IconData icon;
  final Color color;

  CategoryInfo({required this.icon, required this.color});
}
