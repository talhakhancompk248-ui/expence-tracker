import 'package:flutter/foundation.dart';
import 'package:hive/hive.dart';
import '../models/transaction_model.dart';

class TransactionProvider extends ChangeNotifier {
  late Box<TransactionModel> _transactionBox;
  List<TransactionModel> _transactions = [];
  bool _isLoading = false;

  List<TransactionModel> get transactions => _transactions;
  bool get isLoading => _isLoading;

  // Computed properties
  double get totalIncome => _transactions
      .where((t) => t.type == TransactionType.income)
      .fold(0, (sum, t) => sum + t.amount);

  double get totalExpense => _transactions
      .where((t) => t.type == TransactionType.expense)
      .fold(0, (sum, t) => sum + t.amount);

  double get balance => totalIncome - totalExpense;

  TransactionProvider() {
    _init();
  }

  Future<void> _init() async {
    _isLoading = true;
    notifyListeners();

    _transactionBox = Hive.box<TransactionModel>('transactions');
    await loadTransactions();

    _isLoading = false;
    notifyListeners();
  }

  Future<void> loadTransactions() async {
    _transactions = _transactionBox.values.toList();
    // Sort by date descending (newest first)
    _transactions.sort((a, b) => b.date.compareTo(a.date));
    notifyListeners();
  }

  Future<void> addTransaction(TransactionModel transaction) async {
    await _transactionBox.put(transaction.id, transaction);
    await loadTransactions();
  }

  Future<void> updateTransaction(TransactionModel transaction) async {
    await _transactionBox.put(transaction.id, transaction);
    await loadTransactions();
  }

  Future<void> deleteTransaction(String id) async {
    await _transactionBox.delete(id);
    await loadTransactions();
  }

  // Get transactions for specific month
  List<TransactionModel> getTransactionsForMonth(DateTime month) {
    return _transactions
        .where((t) => t.date.year == month.year && t.date.month == month.month)
        .toList();
  }

  // Get monthly summary
  Map<String, double> getMonthlySummary(DateTime month) {
    final monthTransactions = getTransactionsForMonth(month);
    final income = monthTransactions
        .where((t) => t.type == TransactionType.income)
        .fold(0.0, (sum, t) => sum + t.amount);
    final expense = monthTransactions
        .where((t) => t.type == TransactionType.expense)
        .fold(0.0, (sum, t) => sum + t.amount);

    return {'income': income, 'expense': expense, 'balance': income - expense};
  }

  // Get category-wise spending for a month
  Map<String, double> getCategorySpending(DateTime month) {
    final monthTransactions = getTransactionsForMonth(
      month,
    ).where((t) => t.type == TransactionType.expense);

    final Map<String, double> categoryMap = {};
    for (var t in monthTransactions) {
      categoryMap[t.category] = (categoryMap[t.category] ?? 0) + t.amount;
    }
    return categoryMap;
  }

  // Get monthly trend data (last 6 months)
  List<Map<String, dynamic>> getMonthlyTrend() {
    final now = DateTime.now();
    final List<Map<String, dynamic>> trend = [];

    for (int i = 5; i >= 0; i--) {
      final month = DateTime(now.year, now.month - i, 1);
      final summary = getMonthlySummary(month);
      trend.add({
        'month': month,
        'income': summary['income'],
        'expense': summary['expense'],
      });
    }
    return trend;
  }
}
